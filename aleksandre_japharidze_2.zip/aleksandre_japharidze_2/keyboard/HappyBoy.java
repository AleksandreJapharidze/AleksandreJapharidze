package workshop.w1.aleksandre_japharidze_2.javarules;


public class HappyBoy {
}
