package workshop.w1.aleksandre_japharidze_2.package2;

public class B {
    public static void main(String[] args) {
        System.out.println("Hi! I am Class B in package2!");
    }
}
