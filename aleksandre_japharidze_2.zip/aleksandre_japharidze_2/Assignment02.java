package workshop.w1.aleksandre_japharidze_2;
import workshop.w1.aleksandre_japharidze_2.package1.A;
import workshop.w1.aleksandre_japharidze_2.package2.B;

/**
 * Find two packages inside this package.
 * Create classes A and B inside first and the second package accordingly
 * 1 point
*/
public class Assignment02 {
    public static void main(String[] args) {
        System.out.println("Done!");
    }
}
