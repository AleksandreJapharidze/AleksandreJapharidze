package workshop.w1.aleksandre_japharidze_2;


/**
 * Correct formatting, naming conventions and the code itself
 * 1 point
 */
public class Assignment01 {
    public static void main(String[] args) {

        int A = 17;
        int B = 18;

        System.out.println("The sum of the numbers is " + (A + B));
    }
}

//Second solution:

//public class Assignment01 {
//    public static void main(String[] args) {
//
//        int A = 17;
//        int B = 18;
//
//        int sum = A + B;
//
//        System.out.println("The sum of the numbers is " + sum);
//    }
//}