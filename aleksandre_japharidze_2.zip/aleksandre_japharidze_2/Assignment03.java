package workshop.w1.aleksandre_japharidze_2;


/**
 * Find the file "hidden.txt" and print its path.
 * The file should be found yourself without java code.
 * 0.5 points
 */
public class Assignment03 {
    public static void main(String[] args) {
        System.out.println("out/production/aleksandre_japharidze_2/workshop/w1/aleksandre_japharidze_2/fish/saxophone/webcam/hidden.txt");
    }
}
