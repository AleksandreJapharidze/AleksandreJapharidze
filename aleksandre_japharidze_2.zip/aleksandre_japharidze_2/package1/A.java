package workshop.w1.aleksandre_japharidze_2.package1;

public class A {
    public static void main(String[] args) {
        System.out.println("Hi! I am Class A in package1!");
    }
}
