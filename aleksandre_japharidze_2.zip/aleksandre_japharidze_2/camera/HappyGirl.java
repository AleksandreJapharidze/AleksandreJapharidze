package workshop.w1.aleksandre_japharidze_2.iliaunirules;


public class HappyGirl {
}
